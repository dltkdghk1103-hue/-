보고서: extrusion_analysis_report_KO.pdf
수정도면: modified_profile_revA_CONCEPT.dxf / .pdf
원본도면: original_profile_UNCHANGED.dxf

기존 계산값은 원본 형상에 대한 결과입니다. Rev A는 검토용 후보이며 파단·접촉·압출 유동 검증 및 금형 제작 승인 전 상태입니다.
PDF는 도식 축척, DXF는 mm 단위 1:1입니다.
