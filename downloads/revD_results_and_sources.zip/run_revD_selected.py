from revd_design import SELECTED
from revd_contact import run

if __name__=='__main__':
    jobs=[]
    for mu in [.1,.3,.6]:
        for dt in [.00001,.000005,.0000025]:
            jobs.append((SELECTED,dict(id=f'D_rest_{mu}_{dt}',mu=mu,dt=dt,iterations=120,slop=.0001,surface_tol=.0001,duration=.6,wall_seconds_limit=90)))
        for vx,vy,om in [(-100,100,-20),(100,-100,20)]:
            jobs.append((SELECTED,dict(id=f'D_launch_{mu}_{vx}',mu=mu,vx=vx,vy=vy,omega=om,dt=.000005,iterations=120,slop=.0001,surface_tol=.0001,duration=.2,wall_seconds_limit=90)))
    run(jobs,'selected_release_verification.json')
