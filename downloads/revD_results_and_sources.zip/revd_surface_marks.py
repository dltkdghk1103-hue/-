"""Nominal attachment footprints and 2D visibility, NOT fracture surface prediction."""
from revd_design import *
from shapely.affinity import translate
from matplotlib.font_manager import FontProperties

def build():
    p,n,m=candidate(**SELECTED);font=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
    plt.rcParams['font.family']=font.get_name();plt.rcParams['axes.unicode_minus']=False
    rootcent={k:np.array(LineString(rr).interpolate(.5,normalized=True).coords)[0] for k,rr in n.items()}
    axis=n['left_yellow'][-1]-n['left_yellow'][0];axis/=np.linalg.norm(axis)
    normals={'left_green':wall_normal,'left_yellow':np.array([axis[1],-axis[0]])}
    checks=[]
    for down in [0,.5,2,10]:
        yy=translate(Y,yoff=-down)
        for key in rootcent:
            mid=rootcent[key]+np.array([0,-down if key=='left_yellow' else 0]);normal=normals[key];start=mid+normal*.002;visible=[]
            for deg in range(360):
                v=np.array([np.cos(np.deg2rad(deg)),np.sin(np.deg2rad(deg))])
                if v@normal<=.02:continue
                ray=LineString([start,start+400*v])
                if ray.intersection(G).length+ray.intersection(yy).length<1e-5:visible.append(deg)
            checks.append({'yellow_down_mm':down,'root':key,'unobstructed_2d_ray_angles_deg':visible,'any_unobstructed_2d_ray':bool(visible)})
    result={'model':'2D cross-section straight-ray screening at nominal attachment centers. No fracture marks, roughness, coating or 3D end visibility is simulated.','step_deg':1,'ray_start_offset_mm':.002,'product_geometry_changed':False,'checks':checks,'zero_visible_mark_verified':False,'burr_height_computed':False,'negative_tear_depth_computed':False}
    (DEST/'surface_mark_scope_and_visibility.json').write_text(json.dumps(result,indent=2))
    fig,ax=plt.subplots(figsize=(9,6))
    for pp,col in [(G,'#299849'),(Y,'#d7ad00')]:ax.fill(*np.array(pp.exterior.coords).T,color=col,alpha=.8)
    ax.plot(*np.array(p.exterior.coords).T,color='gray',ls='--',lw=1,label='제거할 흰 연결부 윤곽 (참고)')
    for key,label,textpos in [('left_green','초록 제품 내벽 접속띠\n폭 0.25 mm × 길이 방향 연속',(-74.9,100.9)),('left_yellow','노란 제품 R2 접속띠\n폭 약 0.20 mm × 길이 방향 연속',(-73.5,104.3))]:
        ax.plot(*n[key].T,color='#b22',lw=4);ax.annotate(label,xy=rootcent[key],xytext=textpos,fontsize=11,arrowprops={'arrowstyle':'->','color':'#b22'})
    ax.set_xlim(-75.4,-71.2);ax.set_ylim(100.5,105);ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_xlabel('x [mm]');ax.set_ylabel('y [mm]');ax.legend(loc='lower right',fontsize=9)
    ax.set_title('REV D: 파단 흔적이 생길 수 있는 접속 위치\n표시선은 실제 파단선·버 높이·뜯김 폭의 예측이 아닙니다',fontsize=14)
    fig.tight_layout();fig.savefig(DEST/'revD_attachment_witness_locations.png',dpi=180);plt.close(fig)
    print(json.dumps({'visibility':checks},indent=2))
    return result

if __name__=='__main__':build()
