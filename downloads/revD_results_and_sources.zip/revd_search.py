from revd_design import *
from concurrent.futures import ProcessPoolExecutor,as_completed

def worker(args):
    try:
        p,n,m=candidate(**args);r,_=solve(p,n,.02);r.update(m);r['parameters']=args
        return r
    except Exception as e:return {'parameters':args,'error':str(e)}

if __name__=='__main__':
    args=[]
    for x in [-72.3,-72.6,-72.9]:
        for yg in [101.8,102.0,102.25]:
            for k1,k2 in [(.32,.28),(.2,.4),(.4,.15)]:args.append(dict(xy=x,yg=yg,tg=.25,ty=.2,k1=k1,k2=k2))
    results=[]
    with ProcessPoolExecutor(max_workers=4) as ex:
        for f in as_completed([ex.submit(worker,a) for a in args]):
            r=f.result();results.append(r);print(json.dumps(r),flush=True)
    (DEST/'shape_balance_search.json').write_text(json.dumps(results,indent=2))
