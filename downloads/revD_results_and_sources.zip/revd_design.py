"""Rev D: shorter connector to the unchanged yellow R2 corner.
Root on the rounded face follows the original discretized DXF boundary;
no groove, flattening or material removal is made in either product.
"""
from geometry_helpers import *
from revc_design import wall_direction,wall_normal,seg_a,seg_b
from shapely.ops import substring
from shapely.geometry.polygon import orient
from shapely import distance,points

DEST=OUT/'revision_D';DEST.mkdir(exist_ok=True)
SELECTED=dict(xy=-72.3,yg=102.0,tg=.25,ty=.20,width=.50,k1=.32,k2=.28,peak=.4)
YC=np.array([-71.70574582323385,105.00573856686826]);YR=2.0
# Select the original, already flattened R2 segment. Its native CAD arc is preserved.
arr=C['F36A'];start=int(np.argmin(np.linalg.norm(arr-(YC+[0,-2]),axis=1)))
end=int(np.argmin(np.linalg.norm(arr-np.array([-73.43631228272949,104.0031719958749]),axis=1)))
ARC=LineString(arr[start:end+1]);assert ARC.length>2

def candidate(xy=-72.6,yg=102.25,tg=.25,ty=.225,width=.50,k1=.32,k2=.28,peak=.5):
    xg=seg_a[0]+(yg-seg_a[1])*(seg_b[0]-seg_a[0])/(seg_b[1]-seg_a[1])
    a=np.array([xg,yg])
    circlepoint=np.array([xy,YC[1]-np.sqrt(4-(xy-YC[0])**2)])
    arclength=ARC.project(Point(circlepoint))
    assert ty/2<arclength<ARC.length-ty/2
    root=np.array(substring(ARC,arclength+ty/2,arclength-ty/2).coords)
    b=(root[0]+root[-1])/2
    axis=(root[-1]-root[0])/np.linalg.norm(root[-1]-root[0]);enddir=np.array([-axis[1],axis[0]])
    chord_t=np.linalg.norm(root[-1]-root[0]);length=np.linalg.norm(b-a)
    c1=a+wall_normal*length*k1;c2=b-enddir*length*k2
    s=np.linspace(0,1,201)
    p=(1-s[:,None])**3*a+3*(1-s[:,None])**2*s[:,None]*c1+3*(1-s[:,None])*s[:,None]**2*c2+s[:,None]**3*b
    v=3*(1-s[:,None])**2*(c1-a)+6*(1-s[:,None])*s[:,None]*(c2-c1)+3*s[:,None]**2*(b-c2)
    v/=np.linalg.norm(v,axis=1)[:,None];n=np.c_[-v[:,1],v[:,0]]
    base=(1-s)*tg+s*chord_t
    z=np.where(s<=peak,.5*s/peak,.5+.5*(s-peak)/(1-peak))
    w=base+(width-base)*np.sin(np.pi*z)**2
    up=p+n*w[:,None]/2;low=p-n*w[:,None]/2
    assert np.linalg.norm(up[-1]-root[0])<1e-9 and np.linalg.norm(low[-1]-root[-1])<1e-9
    poly=orient(Polygon(np.vstack([up,root[1:-1],low[::-1]])),sign=1)
    roots={'left_green':np.array([up[0],low[0]]),'left_yellow':root}
    overlap=poly.intersection(G).area+poly.intersection(Y).area
    assert poly.is_valid and overlap<1e-6,(xy,yg,tg,ty,overlap)
    meta={'yellow_x_parameter_mm':xy,'green_center_mm':a.tolist(),'yellow_chord_center_mm':b.tolist(),'green_neck_mm':tg,'yellow_arc_neck_mm':ty,'yellow_chord_neck_mm':chord_t,'nominal_body_width_mm':width,'root_center_distance_mm':length,'centerline_length_mm':float(np.linalg.norm(np.diff(p,axis=0),axis=1).sum()),'green_upper_end_to_existing_round_tangent_mm':float(np.linalg.norm(up[0]-seg_a)),'yellow_connection_angle_from_flat_deg':float(np.degrees(np.arctan2(enddir[0],enddir[1]))),'yellow_tangent_flat_point_mm':(YC+[0,-2]).tolist(),'product_overlap_mm2':overlap,'area_mm2':poly.area}
    meta.update({'bezier_first_tangent_fraction':k1,'bezier_second_tangent_fraction':k2,'width_peak_parameter':peak})
    return poly,roots,meta

def solve(poly,roots,h=.015,mode='both'):
    import rigid_bridge as rb
    rb.L=poly;mesh=rb.local_mesh(h);xy=mesh['vertices'];tri=mesh['triangles'];p=xy[tri];n=len(xy);ne=len(tri)
    v1=p[:,1]-p[:,0];v2=p[:,2]-p[:,0];area=(v1[:,0]*v2[:,1]-v1[:,1]*v2[:,0])/2
    b=np.roll(p[:,:,1],-1,axis=1)-np.roll(p[:,:,1],-2,axis=1);c=np.roll(p[:,:,0],-2,axis=1)-np.roll(p[:,:,0],-1,axis=1)
    B=np.zeros((ne,3,6));B[:,0,0::2]=b;B[:,1,1::2]=c;B[:,2,0::2]=c;B[:,2,1::2]=b;B/=2*area[:,None,None]
    E=69000.;nu=.33;D=E/(1-nu**2)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
    ke=np.einsum('eji,jk,ekl,e->eil',B,D,B,area);dofs=np.stack([2*tri,2*tri+1],axis=-1).reshape(ne,6)
    K=coo_matrix((ke.ravel(),(np.repeat(dofs,6,axis=1).ravel(),np.tile(dofs,(1,6)).ravel())),shape=(2*n,2*n)).tocsr()
    edge={key:np.flatnonzero(distance(points(xy),LineString(r))<2e-7) for key,r in roots.items()}
    assert all(len(x)>2 for x in edge.values())
    u=np.zeros(2*n);f=np.zeros(2*n);approach=None
    if mode=='both':
        u[2*edge['left_yellow']+1]=-.001;fixednames=list(edge)
    else:
        fixedname='left_green' if mode=='yellow_first' else 'left_yellow';loadname='left_yellow' if mode=='yellow_first' else 'left_green';fixednames=[fixedname]
        if mode=='yellow_first':
            root=roots[loadname];axis=(root[-1]-root[0])/np.linalg.norm(root[-1]-root[0]);direction=np.array([axis[1],-axis[0]]);approach=-direction[1]
        else:direction=wall_normal;approach=wall_normal[1]
        ids=edge[loadname];line=LineString(roots[loadname]);s=np.array([line.project(Point(x)) for x in xy[ids]]);order=np.argsort(s);ids=ids[order];s=s[order]
        weights=np.zeros(len(s));ds=np.diff(s);weights[:-1]+=ds/2;weights[1:]+=ds/2;weights/=weights.sum()
        f[2*ids]=weights*direction[0];f[2*ids+1]=weights*direction[1]
    fixed=np.unique(np.concatenate([np.r_[2*edge[k],2*edge[k]+1] for k in fixednames]));free=np.setdiff1d(np.arange(2*n),fixed)
    u[free]=spsolve(K[free][:,free],f[free]-K[free][:,fixed]@u[fixed]);reaction=K@u-f
    F=-reaction[2*edge['left_yellow']+1].sum();q=2*F if mode=='both' else 1.
    stress=np.einsum('eij,ej->ei',B,u[dofs])@D.T;sx,sy,tau=stress.T;vm=np.sqrt(sx*sx-sx*sy+sy*sy+3*tau*tau)
    neck={}
    for key,ids in edge.items():
        if key not in fixednames:continue
        ends=roots[key][[0,-1]];mid=ends.mean(axis=0);v=ends[1]-ends[0];t=np.linalg.norm(v);axis=v/t;normal=np.array([-axis[1],axis[0]])
        rf=reaction.reshape(-1,2)[ids];rr=xy[ids]-mid;force=rf.sum(axis=0);moment=(rr[:,0]*rf[:,1]-rr[:,1]*rf[:,0]).sum();normal_force=force@normal;shear_force=force@axis
        equivalent=np.sqrt((abs(normal_force)/t+6*abs(moment)/t**2)**2+3*(1.5*shear_force/t)**2)
        neck[key]={'force_x_per_q':float(force[0]/q),'force_y_per_q':float(force[1]/q),'moment_per_q':float(moment/q),'nominal_equivalent_per_q':float(equivalent/q),'boundary_nodes':len(ids),'section_chord_mm':t}
    result={'h_mm':h,'nodes':n,'elements':ne,'q_N_per_mm_at_0_001mm':float(q),'stiffness_N_per_mm_length_per_mm':float(q/.001),'neck':neck,'net_force_residual':float(np.linalg.norm(reaction.reshape(-1,2).sum(axis=0))),'free_force_residual':float(np.linalg.norm(reaction[free])),'geometry_area_mm2':poly.area,'mesh_area_mm2':float(area.sum())}
    if mode=='both':result['yellow_to_green_nominal_ratio']=neck['left_yellow']['nominal_equivalent_per_q']/neck['left_green']['nominal_equivalent_per_q']
    else:
        result.update({'mode':mode,'contact_compliance_mm_per_N_per_mm':float(f@u),'contact_approach_per_yellow_down':float(approach),'contact_direction':direction.tolist(),'remaining_root':fixedname})
        result.pop('q_N_per_mm_at_0_001mm');result.pop('stiffness_N_per_mm_length_per_mm')
        result['net_force_residual']=float(np.linalg.norm(reaction.reshape(-1,2).sum(axis=0)+direction))
    return result,(xy,tri,u/q,vm/q)

if __name__=='__main__':
    results=[]
    for x in [-72.0,-72.3,-72.6,-72.9,-73.15]:
        p,roots,meta=candidate(xy=x)
        r,_=solve(p,roots);r.update(meta);results.append(r);print(json.dumps(r),flush=True)
    (DEST/'length_search.json').write_text(json.dumps(results,indent=2))
