from revd_design import *
STAGES=[('hot',480,40000,5,12,25),('air_cooled_unaged',25,69000,35,55,90),('aged_T5',25,69000,110,145,170)]

def main():
    results=[];refine=[]
    for tg,ty in [(.20,.20),(.225,.225),(.25,.25),(.25,.20),(.24,.21),(.26,.19)]:
        params=SELECTED|dict(tg=tg,ty=ty);p,n,m=candidate(**params);r,field=solve(p,n,.01);r.update(m);r['parameters']=params
        coef=max(z['nominal_equivalent_per_q'] for z in r['neck'].values());qy=Y.area*2.7e-6*9.81;qall=(Y.area+2*p.area)*2.7e-6*9.81
        r['yellow_weight_6000mm_N']=qy*6000;r['yellow_mass_6000mm_kg']=Y.area*2.7e-6*6000;r['selfweight_q_N_per_mm_including_bridges_as_yellow_load']=qall
        r['selfweight_nominal_stress_MPa']=qall*coef;r['stages']=[]
        for name,T,E,lo,sy,hi in STAGES:
            r['stages'].append({'stage':name,'assumed_temperature_C':T,'assumed_E_MPa':E,'assumed_yield_MPa':[lo,sy,hi],'ratio_nominal_yield_to_selfweight_stress':[v/(qall*coef) for v in [lo,sy,hi]],'nominal_indicator_force_100mm_N':[100*v/coef for v in [lo,sy,hi]],'nominal_indicator_force_6000mm_N':[6000*v/coef for v in [lo,sy,hi]],'critical_remaining_bond_length_mm_for_6000mm_weight':[6000*qall*coef/v for v in [lo,sy,hi]],'intact_selfweight_yellow_down_mm':qall/r['stiffness_N_per_mm_length_per_mm']*69000/E})
        results.append(r);print(json.dumps(r),flush=True)
    p,n,m=candidate(**SELECTED)
    for h in [.02,.01,.005]:
        r,field=solve(p,n,h);refine.append(r)
        if h==.005:
            xy,tr,u,vm=field
            np.savez_compressed(DEST/'revD_elastic_fields.npz',xy=xy,triangles=tr,displacement_per_q=u,vm_per_q=vm)
            mids=[rr[[0,-1]].mean(axis=0) for rr in n.values()];cent=xy[tr].mean(axis=1);dist=np.min(np.stack([np.linalg.norm(cent-v,axis=1) for v in mids]),axis=0)
            r['body_max_vm_per_q_excluding_roots_0_4mm']=float(vm[dist>.4].max())
        print('REFINE',json.dumps(r),flush=True)
    second=[]
    for mode in ['yellow_first','green_first']:
        for h in [.02,.01]:
            r,_=solve(p,n,h,mode=mode);r['stages']=[];coef=r['neck'][r['remaining_root']]['nominal_equivalent_per_q']
            for name,T,E,lo,sy,hi in STAGES:
                force=sy/coef;down=force*r['contact_compliance_mm_per_N_per_mm']*69000/E/r['contact_approach_per_yellow_down']
                r['stages'].append({'stage':name,'remaining_root_nominal_yield_yellow_down_mm':down,'nominal_vertical_force_100mm_N':2*100*force*r['contact_approach_per_yellow_down']})
            second.append(r);print('SECOND',json.dumps(r),flush=True)
    (DEST/'thickness_selfweight_verification.json').write_text(json.dumps({'selected':SELECTED,'variants':results,'mesh_convergence':refine,'second_root':second},indent=2))

if __name__=='__main__':main()
