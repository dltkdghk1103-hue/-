"""Conditional rigid release only, not fracture or extrusion-process simulation."""
from revd_design import candidate,DEST
import revb_contact as dc
from contact_history_checks import check
from shapely.affinity import translate
from shapely.geometry.polygon import orient
from shapely.geometry import Polygon
from shapely import union_all
import numpy as np,json
from concurrent.futures import ProcessPoolExecutor,as_completed

def configure(params):
    dc.B,roots,meta=candidate(**params)
    dc.NECKS={k:r[[0,-1]] for k,r in roots.items()}
    dc.BC=np.array(dc.B.centroid.coords)[0];dc.local=orient(translate(dc.B,xoff=-dc.BC[0],yoff=-dc.BC[1]),sign=1)
    dc.pieces=dc.ag.convex_decomposition(list(dc.local.exterior.coords),.0001)
    dc.decomp=[Polygon(p) for p in dc.pieces];dc.DECOMP=union_all(dc.decomp);dc.MASS=dc.B.area*6000*2.7e-6
    dc.MOMENT=sum(dc.pymunk.moment_for_poly(dc.MASS*p.area/dc.B.area,list(p.exterior.coords)[:-1]) for p in dc.decomp)
    dc.MESHERR=dc.local.symmetric_difference(dc.DECOMP).area
    assert dc.MESHERR/dc.B.area<.005
    return meta

def worker(job):
    params,case=job;meta=configure(params);r=dc.run_case(case);r['geometry']=meta;r['parameters']=params;r['numerical_checks']=check(r)
    return r

def run(jobs,filename):
    results=[]
    with ProcessPoolExecutor(max_workers=4) as ex:
        for f in as_completed([ex.submit(worker,j) for j in jobs]):
            r=f.result();results.append(r)
            print(json.dumps({k:v for k,v in r.items() if k not in ['history','contacts']}),flush=True)
            (DEST/filename).write_text(json.dumps({'complete':len(results)==len(jobs),'results':results}))

if __name__=='__main__':
    jobs=[]
    for x in [-72.0,-72.3,-72.6,-72.9,-73.15]:
        params=dict(xy=x,yg=102.25,tg=.25,ty=.20)
        jobs.append((params,dict(id=f'length_x{x}',mu=.3,dt=.000005,iterations=120,slop=.0001,surface_tol=.0001,duration=.2,wall_seconds_limit=60)))
    run(jobs,'length_release_search.json')
