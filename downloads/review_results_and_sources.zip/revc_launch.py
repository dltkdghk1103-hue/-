from revc_verify import worker,DEST,configure
from contact_history_checks import check
from concurrent.futures import ProcessPoolExecutor,as_completed
import json

if __name__=='__main__':
    cases=[]
    for mu in [.1,.3,.6]:
        for vx,vy,omega in [(-100,100,-20),(100,-100,20),(-100,-100,20),(100,100,-20)]:
            cases.append(dict(id=f'launch_{mu}_{vx}_{vy}_{omega}',mu=mu,vx=vx,vy=vy,omega=omega,duration=.18,dt=.000005,iterations=120,slop=.0001,surface_tol=.0001,wall_seconds_limit=60))
    out=[]
    with ProcessPoolExecutor(max_workers=4) as ex:
        for f in as_completed([ex.submit(worker,c) for c in cases]):
            r=f.result();configure();r['numerical_checks']=check(r);out.append(r)
            (DEST/'release_perturbations.json').write_text(json.dumps({'complete':len(out)==len(cases),'results':out}))
            print(json.dumps({k:v for k,v in r.items() if k!='history'}),flush=True)
