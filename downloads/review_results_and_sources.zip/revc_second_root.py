"""Remaining-root linear elastic compliance under idealized end contact.
Not a fracture calculation or finite-displacement/contact solution.
"""
from revc_design import *
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

def solve(order,h=.01):
    p,ns,meta=candidate(tg=.35);rb.L=p;rb.NECKS=ns
    mesh=rb.local_mesh(h);xy=mesh['vertices'];tri=mesh['triangles'];pts=xy[tri];n=len(xy);ne=len(tri)
    v1=pts[:,1]-pts[:,0];v2=pts[:,2]-pts[:,0];area=np.cross(v1,v2)/2
    b=np.roll(pts[:,:,1],-1,axis=1)-np.roll(pts[:,:,1],-2,axis=1)
    c=np.roll(pts[:,:,0],-2,axis=1)-np.roll(pts[:,:,0],-1,axis=1)
    B=np.zeros((ne,3,6));B[:,0,0::2]=b;B[:,1,1::2]=c;B[:,2,0::2]=c;B[:,2,1::2]=b;B/=2*area[:,None,None]
    E=69000;nu=.33;D=E/(1-nu*nu)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
    ke=np.einsum('eji,jk,ekl,e->eil',B,D,B,area);dofs=np.stack([2*tri,2*tri+1],axis=-1).reshape(ne,6)
    K=coo_matrix((ke.ravel(),(np.repeat(dofs,6,axis=1).ravel(),np.tile(dofs,(1,6)).ravel())),shape=(2*n,2*n)).tocsr()
    edges={}
    for key,ends in ns.items():
        a,bb=ends;v=bb-a;w=xy-a;s=w@v/(v@v);dist=abs(np.cross(w,v))/np.linalg.norm(v)
        edges[key]=np.flatnonzero((dist<2e-7)&(s>=-1e-6)&(s<=1+1e-6))
    if order=='yellow_first':
        fixedname='left_green';loadname='left_yellow';direction=np.array([0.,-1.]);approach_per_down=1.
    else:
        fixedname='left_yellow';loadname='left_green';direction=wall_normal;approach_per_down=wall_normal[1]
    ids=edges[fixedname];fixed=np.unique(np.r_[2*ids,2*ids+1]);free=np.setdiff1d(np.arange(2*n),fixed)
    loadids=edges[loadname];a,bb=ns[loadname];v=bb-a;s=(xy[loadids]-a)@v/(v@v);ii=np.argsort(s);loadids=loadids[ii];s=s[ii]
    weights=np.zeros(len(s));ds=np.diff(s);weights[:-1]+=ds/2;weights[1:]+=ds/2;weights/=weights.sum()
    f=np.zeros(2*n);f[2*loadids]=weights*direction[0];f[2*loadids+1]=weights*direction[1]
    u=np.zeros(2*n);u[free]=spsolve(K[free][:,free],f[free]);reaction=K@u-f
    ends=ns[fixedname];mid=ends.mean(axis=0);axis=(ends[1]-ends[0])/np.linalg.norm(ends[1]-ends[0]);normal=np.array([-axis[1],axis[0]]);t=np.linalg.norm(ends[1]-ends[0])
    rf=reaction.reshape(-1,2)[ids];rr=xy[ids]-mid;F=rf.sum(axis=0);M=np.cross(rr,rf).sum();N=F@normal;V=F@axis
    coef=np.sqrt((abs(N)/t+6*abs(M)/t**2)**2+3*(1.5*V/t)**2)
    compliance=float(f@u)
    out={'order':order,'h_mm':h,'remaining_root':fixedname,'unit_contact_direction':direction.tolist(),'approach_mm_per_mm_yellow_down':float(approach_per_down),'contact_compliance_mm_per_N_per_mm_length':compliance,'root_nominal_MPa_per_N_per_mm_contact':float(coef),'moment_mm_per_unit_contact':float(M),'root_force_per_unit_contact':F.tolist(),'stages':[]}
    for stage,E,sy in [('hot',40000,12),('air_cooled',69000,55),('aged_T5',69000,145)]:
        fn=sy/coef;down=fn*compliance*(69000/E)/approach_per_down
        out['stages'].append({'stage':stage,'assumed_yield_MPa':sy,'one_side_contact_N_per_mm_length_at_nominal_yield':fn,'yellow_down_mm_to_nominal_remaining_root_yield':down,'symmetric_vertical_force_100mm_N_ignoring_gravity_and_friction':2*fn*100*approach_per_down})
    return out

if __name__=='__main__':
    results=[]
    for order in ['yellow_first','green_first']:
        for h in [.02,.01]:
            r=solve(order,h);results.append(r);print(json.dumps(r),flush=True)
    (DEST/'second_root_contact_screening.json').write_text(json.dumps(results,indent=2))
