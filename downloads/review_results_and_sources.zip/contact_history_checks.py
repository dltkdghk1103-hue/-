"""Postcheck every recorded 1 ms pose; sub-millisecond penetration can still be missed."""
import json
import numpy as np
from shapely.affinity import rotate,translate
from revc_verify import configure
import revb_contact as dc
from revc_design import DEST,OUT

def check(r):
    h=np.array(r['history']);ov=[];po=[]
    for row in h:
        b=translate(rotate(dc.local,row[3],use_radians=True,origin=(0,0)),xoff=row[1],yoff=row[2]);y=translate(dc.Y,yoff=row[7])
        ov.append(b.intersection(dc.G).area+b.intersection(y).area)
        po.append(y.intersection(dc.G).area)
    e=(.5*dc.MASS*(h[:,4]**2+h[:,5]**2)+.5*dc.MOMENT*h[:,6]**2+dc.MASS*9810*h[:,2])/1e6
    ei=(.5*dc.MASS*(r['case'].get('vx',0)**2+r['case'].get('vy',0)**2)+.5*dc.MOMENT*r['case'].get('omega',0)**2+dc.MASS*9810*(dc.BC[1]-r['case'].get('dy',0)))/1e6
    return {'id':r['case']['id'],'max_recorded_bridge_overlap_mm2':max(ov),'max_recorded_product_overlap_mm2':max(po),'recording_interval_s':.001,'maximum_mechanical_energy_increase_J':float(max(0,e.max()-ei)),'overlap_tolerance_pass':max(ov)<.005 and max(po)<.02}

if __name__=='__main__':
    # Preserve B globals before configuring C.
    b=json.loads((OUT/'revB_dynamics/sweep.json').read_text())['cases']
    br=[r for r in b if r['case']['id'] in ['fine_0.1','fine_0.3','fine_0.6']]
    bc=[check(r) for r in br]
    configure();c=json.loads((DEST/'release_dynamics.json').read_text());assert c['complete']
    cc=[check(r) for r in c['results']]
    out={'revB':bc,'revC':cc,'note':'Exact polygons checked at stored 1 ms poses. This does not prove all substeps penetration-free.'}
    (DEST/'trajectory_numerical_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
