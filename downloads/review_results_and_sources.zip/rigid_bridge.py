"""Final user-selected model: rigid products; elastic bridge screening only.
No fracture propagation or impact dynamics are solved. Units mm, N, MPa.
Run: PYTHONPATH=/workspace/analysis_extrusion/vendor MPLCONFIGDIR=/tmp/mpl-extrusion python rigid_bridge.py
"""
import json, math
import numpy as np
import triangle
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from shapely.geometry import Polygon, Point
from shapely.affinity import translate, rotate
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from geometry_helpers import OUT,L,R,G,Y,NECKS,SOLID,draw_geom

def local_mesh(h):
    rr=np.array(L.exterior.coords);verts=[]
    for a,b in zip(rr[:-1],rr[1:]):
        num=max(1,int(np.ceil(np.linalg.norm(b-a)/h)))
        verts.extend(a+(b-a)*i/num for i in range(num))
    verts=np.array(verts);seg=np.c_[np.arange(len(verts)),np.roll(np.arange(len(verts)),-1)]
    return triangle.triangulate({'vertices':verts,'segments':seg},f'pq30a{h*h/2:.12f}')

def solve(h):
    mesh=local_mesh(h);xy=mesh['vertices'];tri=mesh['triangles'];p=xy[tri];n=len(xy);ne=len(tri)
    v1=p[:,1]-p[:,0];v2=p[:,2]-p[:,0];area=(v1[:,0]*v2[:,1]-v1[:,1]*v2[:,0])/2
    b=np.roll(p[:,:,1],-1,axis=1)-np.roll(p[:,:,1],-2,axis=1)
    c=np.roll(p[:,:,0],-2,axis=1)-np.roll(p[:,:,0],-1,axis=1)
    B=np.zeros((ne,3,6));B[:,0,0::2]=b;B[:,1,1::2]=c;B[:,2,0::2]=c;B[:,2,1::2]=b;B/=2*area[:,None,None]
    E=69000.;nu=.33;D=E/(1-nu**2)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
    ke=np.einsum('eji,jk,ekl,e->eil',B,D,B,area)
    dofs=np.stack([2*tri,2*tri+1],axis=-1).reshape(ne,6)
    K=coo_matrix((ke.ravel(),(np.repeat(dofs,6,axis=1).ravel(),np.tile(dofs,(1,6)).ravel())),shape=(2*n,2*n)).tocsr()
    edge={}
    for key in ['left_green','left_yellow']:
        a,b=NECKS[key];v=b-a;w=xy-a;s=(w@v)/(v@v);dist=np.abs(w[:,0]*v[1]-w[:,1]*v[0])/np.linalg.norm(v)
        edge[key]=np.flatnonzero((dist<2e-7)&(s> -1e-6)&(s<1+1e-6))
    u=np.zeros(2*n);u[2*edge['left_yellow']+1]=-.001
    fixed=np.unique(np.concatenate([np.r_[2*v,2*v+1] for v in edge.values()]));free=np.setdiff1d(np.arange(2*n),fixed)
    u[free]=spsolve(K[free][:,free],-K[free][:,fixed]@u[fixed]);reaction=K@u
    F=-reaction[2*edge['left_yellow']+1].sum();q=2*F
    stress=np.einsum('eij,ej->ei',B,u[dofs])@D.T
    sx,sy,tau=stress.T;vm=np.sqrt(sx*sx-sx*sy+sy*sy+3*tau*tau)
    neck={}
    for key,ids in edge.items():
        ends=NECKS[key];mid=ends.mean(axis=0);v=ends[1]-ends[0];t=np.linalg.norm(v);axis=v/t;normal=np.array([-axis[1],axis[0]])
        rf=reaction.reshape(-1,2)[ids];rr=xy[ids]-mid;force=rf.sum(axis=0);moment=(rr[:,0]*rf[:,1]-rr[:,1]*rf[:,0]).sum()
        normal_force=force@normal;shear_force=force@axis
        # Nominal end-section stress; no singular corner stress used for strength.
        outer=abs(normal_force)/t+6*abs(moment)/t**2
        equivalent=np.sqrt(outer**2+3*(1.5*shear_force/t)**2)
        neck[key]={'force_x_per_q':float(force[0]/q),'force_y_per_q':float(force[1]/q),'moment_per_q':float(moment/q),'N_per_q':float(normal_force/q),'V_per_q':float(shear_force/q),'nominal_equivalent_per_q':float(equivalent/q),'nominal_normal_extremes_per_q':[(normal_force/t-6*moment/t**2)/q,(normal_force/t+6*moment/t**2)/q]}
    r={'h_mm':h,'nodes':n,'elements':ne,'q_N_per_mm_at_0_001mm':float(q),'stiffness_N_per_mm_length_per_mm_travel':float(q/.001),'neck':neck,'net_force_residual':float(np.linalg.norm(reaction.reshape(-1,2).sum(axis=0))),'free_force_residual':float(np.linalg.norm(reaction[free])),'mesh_area':float(area.sum()),'geometry_area':L.area}
    return r,(xy,tri,u/q,vm/q)

def geometry_drop():
    # Pure translations of the fully separated bridge; products rigid and green stationary.
    # These are collision checks, NOT predicted trajectories.
    shifts=[]
    for drop in [0.1,.5,1,5,20,40,58]:
        def clear(dx):return translate(L,xoff=dx,yoff=-drop).intersection(G).area<1e-9
        low=0.;high=3.
        assert clear(high)
        for _ in range(45):
            mid=(low+high)/2
            if clear(mid):high=mid
            else:low=mid
        shifts.append({'down_mm':drop,'minimum_inward_translation_mm':high,'vertical_only_overlap_mm2':translate(L,yoff=-drop).intersection(G).area})
    shifts_const=[]
    for dx in [.0,.25,.5,1.,1.2,1.5,2.]:
        first=None
        for drop in np.linspace(.01,65,6500):
            if translate(L,xoff=dx,yoff=-drop).intersection(G).area>1e-8:
                first=float(drop);break
        shifts_const.append({'inward_translation_mm':dx,'first_green_collision_down_mm':first})
    both=[]
    for yellow_down in [0.,.5,1.]:
        yy=translate(Y,yoff=-yellow_down)
        for drop in [.1,.5,1.,2.,3.,58.]:
            feasible=[]
            for dx in np.linspace(0,3,601):
                piece=translate(L,xoff=dx,yoff=-drop)
                if piece.intersection(G).area<1e-8 and piece.intersection(yy).area<1e-8:feasible.append(float(dx))
            both.append({'yellow_down_mm':yellow_down,'bridge_down_mm':drop,'feasible_inward_interval_mm_at_0_005mm_grid':None if not feasible else [min(feasible),max(feasible)]})
    return shifts,shifts_const,both

def main():
    draw_geom();results=[]
    for h in [.06,.03,.015,.0075]:
        r,field=solve(h);results.append(r);print(json.dumps(r),flush=True)
    xy,tr,u,vm=field
    fig,axs=plt.subplots(1,2,figsize=(12,5))
    for ax in axs:
        pc=PolyCollection(xy[tr],array=vm,cmap='turbo',clim=(0,60),edgecolors='none');ax.add_collection(pc);ax.autoscale();ax.set_aspect('equal');ax.set_xlabel('x [mm]');ax.set_ylabel('y [mm]')
    axs[0].set_title('Rigid-product model: left bridge, q = 1 N/mm')
    axs[1].set_title('Elastic deformation magnified 200x')
    axs[1].plot(*np.array(L.exterior.coords).T,color='gray',lw=1)
    axs[1].add_collection(PolyCollection((xy+u.reshape(-1,2)*200)[tr],facecolor='none',edgecolor='red',linewidth=.05))
    fig.colorbar(pc,ax=axs,label='Elastic von Mises stress [MPa]',shrink=.65);fig.savefig(OUT/'rigid_bridge_stress.png',dpi=180);plt.close(fig)
    np.savez_compressed(OUT/'rigid_bridge_fields.npz',xy=xy,triangles=tr,displacement_per_q=u,vm_per_q=vm)
    shifts,constant,both=geometry_drop();print('CLEARANCES',json.dumps(shifts),flush=True)
    final=results[-1];coef=max(x['nominal_equivalent_per_q'] for x in final['neck'].values());stiff=final['stiffness_N_per_mm_length_per_mm_travel']
    stages=[]
    for name,T,E,sylo,sy,syhi in [('hot',480,40000,5,12,25),('air_cooled_unaged',25,69000,35,55,90),('aged_T5',25,69000,110,145,170)]:
        qlo=sylo/coef;qnom=sy/coef;qhi=syhi/coef
        d=qnom/(stiff*E/69000)
        stages.append({'stage':name,'assumed_T_C':T,'assumed_E_MPa':E,'assumed_yield_MPa':[sylo,sy,syhi],'nominal_first_yield_q_N_per_mm':[qlo,qnom,qhi],'force_100mm_N':[100*qlo,100*qnom,100*qhi],'force_6000mm_N':[6000*qlo,6000*qnom,6000*qhi],'nominal_first_yield_displacement_mm':d,'elastic_energy_to_first_yield_100mm_J':.5*qnom*100*d/1000})
    # Lumped cooling using entire section, all exposed perimeter as upper cooling estimate.
    A=SOLID.area*1e-6;rho=2700;cp=1000;T0=510;Ta=25
    thermal=[]
    for h in [10,30,80]:
        for perimeter_name,P in [('all_perimeter',SOLID.length*.001),('outer_only',SOLID.exterior.length*.001)]:
            tau=rho*cp*A/(h*P)
            for speed in [5,10,20]:
                t=60/speed;T=Ta+(T0-Ta)*math.exp(-t/tau)
                thermal.append({'h_W_m2K':h,'perimeter_case':perimeter_name,'speed_m_min':speed,'time_to_1m_s':t,'temperature_at_1m_C':T,'tau_s':tau})
    out={'model':'Rigid products; elastic plane-stress bridge, linear small displacement. No fracture or impact simulation.','geometry':{'neck_mm':.25,'bridge_area_mm2':L.area,'bridge_mass_6m_g':L.area*16.2,'bridge_span_mm':np.linalg.norm(NECKS['left_yellow'].mean(axis=0)-NECKS['left_green'].mean(axis=0)),'cavity_height_mm':59.7693182627,'total_mass_6m_kg':SOLID.area*.0162},'mesh_convergence':results,'material_sensitivity':stages,'geometric_clearance':shifts,'translated_drop_collision':constant,'both_products_collision':both,'thermal_sensitivity':thermal}
    (OUT/'rigid_results.json').write_text(json.dumps(out,indent=2));print('STAGES',json.dumps(stages),flush=True)
    # Collision illustration: red vertical-only path hits the sloping wall, blue inward offset clears it.
    fig,axs=plt.subplots(1,2,figsize=(11,6))
    for ax in axs:
        for pp,col in [(G,'#31a354'),(translate(Y,yoff=-1),'#d4aa00')]:
            a=np.array(pp.exterior.coords);ax.fill(*a.T,color=col,alpha=.65)
        a=np.array(L.exterior.coords);ax.fill(*a.T,color='gray');ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_xlabel('x [mm]');ax.set_ylabel('y above floor [mm]')
    axs[0].set_xlim(-76.2,-71.5);axs[0].set_ylim(99.5,104.5)
    for dx,col in [(0,'red'),(1.5,'#167ac6')]:
        pp=translate(L,xoff=dx,yoff=-3);a=np.array(pp.exterior.coords);axs[0].plot(*a.T,color=col)
    axs[0].set_title('Bridge 3 mm down, yellow 1 mm down\nRed: wall collision; blue: +1.5 mm inward clears both')
    axs[1].set_xlim(-78,-65);axs[1].set_ylim(40,108)
    for dx,col in [(0,'red'),(1.5,'#167ac6')]:
        c=np.array(L.centroid.coords)[0];axs[1].plot([c[0]+dx,c[0]+dx],[c[1],44],color=col,ls='--')
    axs[1].set_title('Geometric clearance only, not a simulated fall')
    fig.tight_layout();fig.savefig(OUT/'clearance.png',dpi=180);plt.close(fig)

if __name__=='__main__':main()
