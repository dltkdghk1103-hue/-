"""Conditional post-release rigid-body contact dynamics for Rev B.
This does NOT simulate fracture, plasticity, extrusion, or longitudinal strip dynamics.
Units: mm, kg, seconds. Contact geometry derived from unchanged user products.
"""
from pathlib import Path
import json, math, time, argparse
import numpy as np
import ezdxf
from ezdxf.path import make_path
from shapely.geometry import Polygon
from shapely.geometry.polygon import orient
from shapely.affinity import rotate,translate
from shapely import set_precision,union_all
import pymunk
import pymunk.autogeometry as ag
from geometry_helpers import G,Y,L,C,OUT,XC,Y0,NECKS

DEST=OUT/'revB_dynamics';DEST.mkdir(exist_ok=True)
doc=ezdxf.readfile(OUT/'revision_B/modified_bridge_only_revB_CONCEPT.dxf')
upper=[]
for e in doc.modelspace():
    if e.dxftype()=='LWPOLYLINE' and len(e)==2 and e.dxf.layer!='REV_B_NOTES':
        pts=np.array([[v.x-XC,v.y-Y0] for v in make_path(e).flattening(.0001)])
        if pts[:,0].mean()<0:upper=pts
assert len(upper)>0
B=orient(set_precision(Polygon(np.vstack([upper,C['F36D'][::-1]])),1e-7),sign=1)
BC=np.array(B.centroid.coords)[0]
local=orient(translate(B,xoff=-BC[0],yoff=-BC[1]),sign=1)
pieces=ag.convex_decomposition(list(local.exterior.coords),.0005)
decomp=[Polygon(p) for p in pieces]
DECOMP=union_all(decomp)
assert abs(DECOMP.area-B.area)/B.area<.005
MASS=B.area*6000*2.7e-6 # One full 6 m strip, rigid and uniformly released in z.
MOMENT=sum(pymunk.moment_for_poly(MASS*p.area/B.area,list(p.exterior.coords)[:-1]) for p in decomp)
MESHERR=local.symmetric_difference(DECOMP).area

def surface(space,poly,body,mu,e,ctype,tol=.0005):
    pts=np.array(poly.simplify(tol,preserve_topology=True).exterior.coords)[:-1]
    shapes=[]
    for i in range(len(pts)):
        a=pts[i];b=pts[(i+1)%len(pts)]
        s=pymunk.Segment(body,tuple(a),tuple(b),0)
        s.set_neighbors(tuple(pts[(i-1)%len(pts)]),tuple(pts[(i+2)%len(pts)]))
        s.friction=math.sqrt(mu);s.elasticity=math.sqrt(e);s.collision_type=ctype
        shapes.append(s)
    space.add(*shapes)
    return shapes

def run_case(case):
    mu=case.get('mu',.3);rest=case.get('restitution',.1);dt=case.get('dt',.00002);duration=case.get('duration',.6)
    space=pymunk.Space();space.gravity=(0,-9810);space.iterations=case.get('iterations',60)
    space.collision_slop=case.get('slop',.0005);space.collision_bias=pow(1-.2,60)
    space.damping=1.0 # No artificial global damping.
    surface(space,G,space.static_body,mu,rest,2,case.get('surface_tol',.0005))
    force_mode=case.get('yellow_mode')=='force'
    yellow_mass_half=Y.area*6000*2.7e-6/2
    yellow=pymunk.Body(yellow_mass_half,float('inf')) if force_mode else pymunk.Body(body_type=pymunk.Body.KINEMATIC)
    space.add(yellow)
    if force_mode:
        # Symmetric half-model: half yellow mass and half central force; x and rotation cancel by symmetry.
        guide=pymunk.GrooveJoint(space.static_body,yellow,(0,-200),(0,200),(0,0));space.add(guide)
    surface(space,Y,yellow,mu,rest,3,case.get('surface_tol',.0005))
    body=pymunk.Body(MASS,MOMENT)
    body.position=tuple(BC+np.array([case.get('dx',0),-case.get('dy',0)]))
    body.angle=case.get('angle',0)
    body.velocity=(case.get('vx',0),case.get('vy',0));body.angular_velocity=case.get('omega',0)
    space.add(body)
    for p in decomp:
        s=pymunk.Poly(body,list(p.exterior.coords)[:-1]);s.friction=math.sqrt(mu);s.elasticity=math.sqrt(rest);s.collision_type=1
        space.add(s)
    y_initial=case.get('yellow_initial_down',0);y_speed=case.get('yellow_speed',0);y_stroke=case.get('yellow_stroke',0)
    yellow.position=(0,-y_initial)
    if force_mode:yellow.velocity=(0,-case.get('yellow_initial_speed',0))
    # Optional intact perfect hinge: a favorable rotational freedom limit, not an actual ligament model.
    if case.get('hinge')=='yellow':
        anchor=NECKS['left_yellow'].mean(axis=0)
        j=pymunk.PivotJoint(body,yellow,body.world_to_local(tuple(anchor)),yellow.world_to_local(tuple(anchor)))
        j.collide_bodies=True;space.add(j)
    history=[];sample=max(1,round(.001/dt));starttime=time.perf_counter();incomplete=False
    for i in range(round(duration/dt)):
        t=i*dt
        if force_mode:
            yellow.force=(0,-case.get('hand_force_N',0)*1000/2)
        else:
            next_y=-y_initial-min(y_stroke,y_speed*(t+dt))
            yellow.velocity=(0,(next_y-yellow.position.y)/dt)
        space.step(dt)
        if i%sample==0:
            history.append([t+dt,body.position.x,body.position.y,body.angle,body.velocity.x,body.velocity.y,body.angular_velocity,yellow.position.y])
        if i>0 and i%5000==0 and time.perf_counter()-starttime>case.get('wall_seconds_limit',float('inf')):
            incomplete=True;duration=t+dt;break
    history=np.array(history)
    transformed=translate(rotate(local,body.angle,use_radians=True,origin=(0,0)),xoff=body.position.x,yoff=body.position.y)
    yy=translate(Y,yoff=yellow.position.y)
    overlap=transformed.intersection(G).area+transformed.intersection(yy).area
    product_overlap=G.intersection(yy).area
    tail=history[history[:,0]>duration-.1]
    tail_speed=np.sqrt(tail[:,4]**2+tail[:,5]**2)
    drop=float(BC[1]-body.position.y)
    inside_floor=body.position.y<46 and -76<body.position.x<76 and drop>50
    settled=inside_floor and float(np.max(tail_speed))<5 and float(np.max(abs(tail[:,6])))<1
    contacts=[]
    def collect(arb):
        first=arb.shapes[0].body==body
        normal=np.array(tuple(arb.normal))*(-1 if first else 1)
        for cp in arb.contact_point_set.points:
            pt=cp.point_a if first else cp.point_b
            contacts.append({'point':list(pt),'normal_into_bridge':normal.tolist(),'other_collision_type':arb.shapes[1 if first else 0].collision_type})
    body.each_arbiter(collect)
    if incomplete:status='INCOMPLETE_RUNTIME_LIMIT'
    elif overlap>.005 or product_overlap>.02:status='INVALID_PENETRATION'
    elif case.get('hinge'):status='ATTACHED_HINGE'
    elif settled:status='FLOOR_SETTLED'
    elif inside_floor:status='FLOOR_NOT_SETTLED'
    elif drop<5:status='TOP_RETAINED'
    elif drop<50:status='SIDE_OR_TRANSIT'
    else:status='OTHER'
    first_floor=next((float(row[0]) for row in history if row[2]<46),None)
    return {'case':case,'status':status,'final_drop_mm':drop,'final_x_mm':float(body.position.x),'final_y_mm':float(body.position.y),'final_angle_rad':float(body.angle),'yellow_final_down_mm':float(-yellow.position.y),'product_overlap_mm2':product_overlap,'tail_max_speed_mm_s':float(np.max(tail_speed)),'tail_max_omega_rad_s':float(np.max(abs(tail[:,6]))),'final_overlap_area_mm2':overlap,'time_to_floor_zone_s':first_floor,'simulation_seconds':time.perf_counter()-starttime,'contacts':contacts,'history':history.tolist()}

def sanity():
    space=pymunk.Space();space.gravity=(0,-9810);b=pymunk.Body(1,1);space.add(b);b.position=(0,100)
    dt=.00002
    for _ in range(5000):space.step(dt)
    exact=100-.5*9810*.1**2;err=abs(b.position.y-exact)
    assert err<.02
    return {'freefall_0_1s_error_mm':err,'bridge_mass_6m_kg':MASS,'bridge_polar_moment_kg_mm2':MOMENT,'convex_pieces':len(decomp),'area_mm2':B.area,'convex_decomposition_area_error_mm2':MESHERR,'pymunk_version':pymunk.version}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');args=parser.parse_args()
    print(json.dumps(sanity()),flush=True)
    cases=[{'id':'rest_mu01','mu':.1},{'id':'rest_mu03','mu':.3},{'id':'rest_mu06','mu':.6},
     {'id':'press_10','mu':.3,'yellow_speed':10,'yellow_stroke':3},
     {'id':'press_50','mu':.3,'yellow_speed':50,'yellow_stroke':3},
     {'id':'kick_in','mu':.3,'vx':50,'vy':-50},
     {'id':'kick_out','mu':.3,'vx':-50,'vy':-50},
     {'id':'hinge_press','mu':.3,'yellow_speed':10,'yellow_stroke':3,'hinge':'yellow'}]
    results=[]
    for case in cases:
        r=run_case(case);results.append(r);print(json.dumps({k:v for k,v in r.items() if k!='history'}),flush=True)
    (DEST/'pilot.json').write_text(json.dumps({'sanity':sanity(),'results':results}))
