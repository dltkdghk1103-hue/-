"""Connector-only Rev C screening. All release dynamics assume BOTH roots already cut."""
from revc_design import candidate,DEST
import revb_contact as dc
import rigid_bridge as rb
import numpy as np
import json, argparse
from shapely.affinity import translate
from shapely.geometry.polygon import orient
from shapely.geometry import Polygon
from shapely import union_all
from concurrent.futures import ProcessPoolExecutor,as_completed

def configure():
    dc.B,dc.NECKS,meta=candidate(tg=.35)
    dc.BC=np.array(dc.B.centroid.coords)[0]
    dc.local=orient(translate(dc.B,xoff=-dc.BC[0],yoff=-dc.BC[1]),sign=1)
    dc.pieces=dc.ag.convex_decomposition(list(dc.local.exterior.coords),.0001)
    dc.decomp=[Polygon(p) for p in dc.pieces]
    dc.DECOMP=union_all(dc.decomp)
    dc.MASS=dc.B.area*6000*2.7e-6
    dc.MOMENT=sum(dc.pymunk.moment_for_poly(dc.MASS*p.area/dc.B.area,list(p.exterior.coords)[:-1]) for p in dc.decomp)
    dc.MESHERR=dc.local.symmetric_difference(dc.DECOMP).area
    return meta

def worker(case):
    configure()
    return dc.run_case(case)

def fem():
    out=[]
    for tg,ty,h in [(.28,.25,.02),(.35,.25,.02),(.35,.25,.01),(.35,.25,.005),(.33,.27,.02),(.37,.23,.02)]:
        rb.L,rb.NECKS,meta=candidate(tg=tg,ty=ty)
        r,field=rb.solve(h);meta.update(r)
        meta['yellow_to_green_ratio']=r['neck']['left_yellow']['nominal_equivalent_per_q']/r['neck']['left_green']['nominal_equivalent_per_q']
        xy,tr,u,vm=field;cent=xy[tr].mean(axis=1)
        dist=np.minimum(np.linalg.norm(cent-rb.NECKS['left_green'].mean(axis=0),axis=1),np.linalg.norm(cent-rb.NECKS['left_yellow'].mean(axis=0),axis=1))
        meta['body_vm_max_per_q_excluding_root_0_5mm']=float(vm[dist>.5].max())
        meta['body_vm_p95_per_q_excluding_root_0_5mm']=float(np.percentile(vm[dist>.5],95))
        out.append(meta);print(json.dumps(meta),flush=True)
        if h==.005:np.savez_compressed(DEST/'revC_elastic_fields.npz',xy=xy,triangles=tr,displacement_per_q=u,vm_per_q=vm)
    (DEST/'fem_verification.json').write_text(json.dumps(out,indent=2))

def dynamic():
    cases=[]
    for mu in [.1,.3,.6]:
        for dt in [.00002,.000005]:
            cases.append(dict(id=f'C_rest_mu{mu}_dt{dt}',mu=mu,dt=dt,iterations=120,slop=.0001,surface_tol=.0001))
        # Baseline released-piece convergence is isolated from continued force on
        # the products, which causes later product-product collisions.
        cases.append(dict(id=f'C_rest_mu{mu}_dt2.5e-06',mu=mu,dt=.0000025,iterations=120,slop=.0001,surface_tol=.0001,duration=.3))
    results=[]
    with ProcessPoolExecutor(max_workers=4) as ex:
        for future in as_completed([ex.submit(worker,c) for c in cases]):
            r=future.result()
            results.append(r);print(json.dumps({k:v for k,v in r.items() if k!='history'}),flush=True)
            configure()
            (DEST/'release_dynamics.json').write_text(json.dumps({'sanity':dc.sanity(),'results':results,'complete':len(results)==len(cases),'expected_case_count':len(cases)}))
    configure()
    (DEST/'release_dynamics.json').write_text(json.dumps({'sanity':dc.sanity(),'results':results,'complete':True,'expected_case_count':len(cases)}))

if __name__=='__main__':
    import sys
    fem() if sys.argv[-1]=='fem' else dynamic()
