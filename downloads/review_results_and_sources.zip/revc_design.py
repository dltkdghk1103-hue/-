"""Connector-only candidate placed below the original yellow plate.
Product geometry is read-only. All dimensions are exploratory, not tooling approval.
"""
from geometry_helpers import *
import rigid_bridge as rb
from shapely.geometry.polygon import orient
import json

DEST=OUT/'revision_C';DEST.mkdir(exist_ok=True)
YG=101.5
# Exact straight portion of the original left green inner wall.
seg_a=C['F3A3'][np.argmin(np.linalg.norm(C['F3A3']-np.array([-74.789351,102.500152]),axis=1))]
seg_b=next(p for p in C['F3A3'] if p[1]<90)
wall_direction=(seg_b-seg_a)/np.linalg.norm(seg_b-seg_a)
wall_normal=np.array([-wall_direction[1],wall_direction[0]])
yellow_bottom=float(np.min(C['F36A'][:,1]))

def candidate(tg=.4,ty=.25,xy=-70.8,yg=101.5,width=.65):
    xg=seg_a[0]+(yg-seg_a[1])*(seg_b[0]-seg_a[0])/(seg_b[1]-seg_a[1])
    a=np.array([xg,yg]);b=np.array([xy,yellow_bottom]);length=np.linalg.norm(b-a)
    c1=a+wall_normal*length*.32;c2=b+np.array([0,-length*.28])
    s=np.linspace(0,1,241)
    p=(1-s[:,None])**3*a+3*(1-s[:,None])**2*s[:,None]*c1+3*(1-s[:,None])*s[:,None]**2*c2+s[:,None]**3*b
    v=3*(1-s[:,None])**2*(c1-a)+6*(1-s[:,None])*s[:,None]*(c2-c1)+3*s[:,None]**2*(b-c2)
    v/=np.linalg.norm(v,axis=1)[:,None];n=np.c_[-v[:,1],v[:,0]]
    # Smoothly widen the body while retaining endpoint widths.
    w=(1-s)*tg+s*ty+(width-((1-s)*tg+s*ty))*np.sin(np.pi*s)**2
    up=p+n*w[:,None]/2;low=p-n*w[:,None]/2
    poly=orient(Polygon(np.vstack([up,low[::-1]])),sign=1)
    necks={'left_green':np.array([up[0],low[0]]),'left_yellow':np.array([up[-1],low[-1]])}
    overlap=poly.intersection(G).area+poly.intersection(Y).area
    assert poly.is_valid and overlap<1e-6,(tg,ty,overlap)
    return poly,necks,{'green_center':a.tolist(),'yellow_center':b.tolist(),'green_neck_mm':tg,'yellow_neck_mm':ty,'nominal_body_width_mm':width,'chord_length_mm':length,'product_overlap_area_mm2':overlap}

if __name__=='__main__':
    results=[]
    for tg in [.25,.30,.35,.40,.45,.50,.55]:
        p,n,meta=candidate(tg=tg)
        rb.L=p;rb.NECKS=n
        r,_=rb.solve(.02)
        meta.update(r)
        meta['yellow_to_green_nominal_stress_ratio']=r['neck']['left_yellow']['nominal_equivalent_per_q']/r['neck']['left_green']['nominal_equivalent_per_q']
        results.append(meta);print(json.dumps(meta),flush=True)
    (DEST/'neck_balance_search.json').write_text(json.dumps(results,indent=2))
