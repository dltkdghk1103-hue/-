"""DXF geometry helpers for the final rigid-products bridge screening.
Units: mm, N, MPa. No input file is modified.
Run with PYTHONPATH=/workspace/analysis_extrusion/vendor MPLCONFIGDIR=/tmp/mpl-extrusion.
"""
import os, json, math
from pathlib import Path
import numpy as np
import ezdxf, triangle
from ezdxf.path import make_path
from shapely.geometry import Polygon, Point, LineString
from shapely import set_precision, union_all, contains_xy
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection

OUT=Path(__file__).resolve().parent
INPUT=OUT/'ddfdfd.dxf'
if not INPUT.exists():
    INPUT=Path('/workspace/attachments/c3d6cee3-481f-4b82-aa72-2e7e5ff5b5b4/ddfdfd.dxf')
DOC=ezdxf.readfile(INPUT)
XC=282.500612101613
Y0=107.18261973711121
def curve(h):
    return np.array([[p.x-XC,p.y-Y0] for p in make_path(DOC.entitydb[h]).flattening(.0003)])
C={h:curve(h) for h in ['F369','F36A','F36C','F36D','F36E','F36F','F3A2','F3A3']}
G=set_precision(Polygon(np.vstack([C['F369'],C['F3A3']])),1e-7)
Y=set_precision(Polygon(np.vstack([C['F36A'],C['F3A2']])),1e-7)
L=set_precision(Polygon(np.vstack([C['F36C'],C['F36D'][::-1]])),1e-7)
R=set_precision(Polygon(np.vstack([C['F36E'],C['F36F'][::-1]])),1e-7)
PARTS=[G,Y,L,R]
SOLID=union_all(PARTS)
assert SOLID.geom_type=='Polygon' and SOLID.is_valid and len(SOLID.interiors)==1
NECKS={
 'left_green':np.array([C['F36C'][0],C['F36D'][0]]),
 'left_yellow':np.array([C['F36C'][-1],C['F36D'][-1]]),
 'right_green':np.array([C['F36E'][0],C['F36F'][0]]),
 'right_yellow':np.array([C['F36E'][-1],C['F36F'][-1]])}

def draw_geom():
    fig,axs=plt.subplots(1,2,figsize=(14,7),gridspec_kw={'width_ratios':[1.35,1]})
    for ax in axs:
        for p,col in zip(PARTS,['#31a354','#e6b800','#888888','#888888']):
            xy=np.array(p.exterior.coords); ax.fill(xy[:,0],xy[:,1],color=col,alpha=.8)
        ax.set_aspect('equal'); ax.grid(alpha=.2);ax.set_xlabel('x [mm]');ax.set_ylabel('y above floor [mm]')
    axs[0].set_title('Actual DXF section (mm); downward loading')
    for x in [-45,45]:axs[0].annotate('',xy=(x,106),xytext=(x,135),arrowprops={'arrowstyle':'->','lw':2,'color':'#b22222'})
    axs[0].axhline(0,color='black');axs[0].text(0,65,'Internal cavity',ha='center')
    axs[1].set_xlim(-76.3,-72.8);axs[1].set_ylim(102.7,105.4);axs[1].set_title('Left bridge: identical 0.250 mm end necks')
    for name in ['left_green','left_yellow']:
        n=NECKS[name];axs[1].plot(n[:,0],n[:,1],'r--',lw=1)
        mid=n.mean(axis=0);axs[1].annotate(name.replace('left_','')+' neck\n0.250 mm',xy=mid,xytext=mid+np.array([-.4 if 'green' in name else .25,1]),arrowprops={'arrowstyle':'->'},fontsize=10)
    axs[1].annotate('Cavity / inward',xy=(-73.7,103.0),xytext=(-75.3,103.0),arrowprops={'arrowstyle':'->'})
    fig.tight_layout();fig.savefig(OUT/'geometry.png',dpi=180);plt.close(fig)
