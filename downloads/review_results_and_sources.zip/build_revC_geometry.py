"""Native product entity preservation, concept assembly and review figures."""
from revc_design import *
import ezdxf
from shapely.affinity import scale,translate
from shapely import union_all
from matplotlib.font_manager import FontProperties
from weasyprint import HTML

font=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams['font.family']=font.get_name();plt.rcParams['axes.unicode_minus']=False

def draw(ax,parts):
    for p,col in parts:
        a=np.array(p.exterior.coords);ax.fill(*a.T,color=col,alpha=.85)
    ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_xlabel('x [mm]');ax.set_ylabel('y [mm]')

def main():
    p,ns,meta=candidate(tg=.35);right=scale(p,xfact=-1,yfact=1,origin=(0,0))
    original=ezdxf.readfile(OUT/'ddfdfd.dxf');doc=ezdxf.readfile(OUT/'ddfdfd.dxf');ms=doc.modelspace()
    for h in ['F36C','F36D','F36E','F36F']:ms.delete_entity(doc.entitydb[h])
    for layer,color in [('REV_C_WHITE_BRIDGE',7),('ORIGINAL_PRODUCT_END_FACES',8),('REV_C_NOTES',1)]:doc.layers.new(layer,dxfattribs={'color':color})
    # Original open product entities are retained byte-for-byte geometrically.
    # Their existing inferred neck end faces are made explicit after relocating the bridge.
    for name,ends in NECKS.items():
        color=3 if 'green' in name else 2
        ms.add_line(ends[0]+[XC,Y0],ends[1]+[XC,Y0],dxfattribs={'layer':'ORIGINAL_PRODUCT_END_FACES','color':color})
    for poly in [p,right]:
        ms.add_lwpolyline(np.array(poly.exterior.coords)[:-1]+[XC,Y0],close=True,dxfattribs={'layer':'REV_C_WHITE_BRIDGE','color':7})
    notes=['REV C / CONNECTOR RELOCATION CONCEPT / NOT FOR TOOLING',
      'Original yellow + green entity coordinates, bulges, widths and flags unchanged.',
      'No product steps, grooves or guides. Only white bridge relocated / reshaped.',
      'Left roots, normalized origin: original x=282.5006121, y=107.1826197 mm.',
      'Green root center: (-74.774808, 101.500000), neck 0.350 mm.',
      'Yellow root center: (-70.800000, 103.005739), neck 0.250 mm.',
      'Body nominal width 0.650 mm; root center chord 4.250453 mm.',
      'Right bridge is mirror about original x=282.5006121.',
      'Product lines under bridge roots are material interfaces, NOT cutting slots.',
      'Original end faces close the already-assumed product shapes; no added volume.',
      'Assembly/reference contours overlap at interfaces. NOT a die-wire cutting contour.',
      'CAD uses sampled smooth curves. Toolmaker must fit / review curves and flow.',
      'Both-root fracture, burrs, hot plasticity and 6 m release NOT validated.',
      'Released-piece motion is conditional on complete prior root separation.']
    for i,t in enumerate(notes):ms.add_text(t,dxfattribs={'layer':'REV_C_NOTES','height':2.0,'insert':(175,295-i*4)})
    file=DEST/'bridge_relocated_revC_CONCEPT.dxf';doc.saveas(file)
    saved=ezdxf.readfile(file);assert not saved.audit().has_errors
    checks={}
    for h in ['F369','F36A','F3A2','F3A3']:
        a,b=original.entitydb[h],saved.entitydb[h]
        good=np.array_equal(np.array(a.get_points()),np.array(b.get_points())) and a.closed==b.closed and a.dxf.color==b.dxf.color and a.dxf.layer==b.dxf.layer
        assert good;checks[h]={'native_vertices_bulges_widths_flags_identical':bool(good),'vertex_count':len(a)}
    combined=union_all([G,Y,p,right]);assert combined.is_valid and combined.geom_type=='Polygon'
    meta.update({'product_entities':checks,'source_origin_mm':[XC,Y0],'bridge_area_mm2':p.area,'one_bridge_6m_mass_g':p.area*16.2,'right_bridge_product_overlap_mm2':right.intersection(G).area+right.intersection(Y).area,'connected_solid_components':1,'closed_internal_holes':len(combined.interiors),'product_outline_changed':False,'full_fracture_verified':False,'die_manufacturing_verified':False})
    (DEST/'geometry_preservation.json').write_text(json.dumps(meta,indent=2))
    fig,axs=plt.subplots(1,3,figsize=(17,6),gridspec_kw={'width_ratios':[1.3,1,1]})
    draw(axs[0],[(G,'#299849'),(Y,'#d7ad00'),(p,'#888888'),(right,'#888888')]);axs[0].set_title('전체 단면: 제품 윤곽 그대로\n흰 연결부만 판 아래로 이동')
    axs[0].annotate('누르는 면',xy=(-30,106),xytext=(-30,130),ha='center',arrowprops={'arrowstyle':'->','color':'#b22'})
    import revb_contact as dc
    draw(axs[1],[(G,'#299849'),(Y,'#d7ad00'),(dc.B,'#888888')]);axs[1].set_title('REV B / 기존 상단 접속 위치')
    draw(axs[2],[(G,'#299849'),(Y,'#d7ad00'),(p,'#888888')]);axs[2].set_title('REV C / 내부 하향 굽힘 연결부')
    for ax in axs[1:]:ax.set_xlim(-76,-69.5);ax.set_ylim(99.7,106.2)
    for key,label,offset in [('left_green','초록 목 0.35',(-.8,-1.2)),('left_yellow','노랑 목 0.25',(.1,1.2))]:
        a=ns[key];mid=a.mean(0);axs[2].plot(*a.T,color='#c22',lw=2)
        axs[2].annotate(label,xy=mid,xytext=mid+offset,fontsize=9,arrowprops={'arrowstyle':'->'})
    axs[2].annotate('몸통 약 0.65',xy=p.centroid.coords[0],xytext=(-72.8,100),fontsize=9,arrowprops={'arrowstyle':'->'})
    fig.suptitle('연결부 위치·형태 변경안 — 제품 턱·홈 추가 없음',fontsize=17)
    fig.tight_layout();fig.savefig(DEST/'revC_geometry.png',dpi=180);plt.close(fig)
    # Concept load paths. Arrows indicate imposed contact forces, NOT calculated fractures.
    fig,axs=plt.subplots(1,2,figsize=(12,6))
    for ax in axs:
        draw(ax,[(G,'#299849'),(Y,'#d7ad00'),(p,'#888888')]);ax.set_xlim(-75.6,-69.7);ax.set_ylim(99.5,105.3)
    axs[0].set_title('노란 목이 먼저 분리된 경우\n판 밑면이 연결부 끝을 계속 누르는 배치')
    b=ns['left_yellow'].mean(0);a=ns['left_green'].mean(0)
    axs[0].plot(*ns['left_yellow'].T,color='red',lw=4);axs[0].annotate('',xy=b-[0,.5],xytext=b+[0,1.3],arrowprops={'arrowstyle':'->','lw':2,'color':'#b22'})
    axs[0].annotate('남은 초록 목에 굽힘',xy=a,xytext=(-74.5,100),arrowprops={'arrowstyle':'->'},fontsize=10)
    axs[1].set_title('초록 목이 먼저 분리된 경우\n기존 경사벽 접촉 시에만 노란 목에 추가 굽힘')
    axs[1].plot(*ns['left_green'].T,color='red',lw=4);axs[1].annotate('',xy=a+[1,0],xytext=a,arrowprops={'arrowstyle':'->','lw':2,'color':'#b22'})
    axs[1].annotate('벽은 하강 1 mm당\n안쪽으로 약 0.0145 mm\n균열 틈이 생기면 접촉 지연',xy=a,xytext=(-73.7,99.9),fontsize=10,arrowprops={'arrowstyle':'->'})
    fig.text(.5,.02,'하중 전달 경로를 보여주는 도식입니다. 완전 파단·버 제거를 계산한 결과가 아닙니다.',ha='center',fontsize=11)
    fig.tight_layout(rect=(0,.06,1,1));fig.savefig(DEST/'second_root_paths.png',dpi=180);plt.close(fig)
    html='''<!doctype html><html lang="ko"><meta charset="utf-8"><style>@page{size:A3 landscape;margin:12mm}body{font-family:"Noto Sans CJK KR";font-size:11pt;line-height:1.5}h1{font-size:18pt}img{width:100%}table{border-collapse:collapse;width:100%}td,th{border:1px solid #aaa;padding:5px}</style><h1>REV C — 연결부 위치·형태 변경 검토도</h1><p>A6063 / 최종 T5 · 길이 6,000 mm · DXF mm, 1:1 · 이 PDF 그림은 도식 축척</p><img src="revC_geometry.png"><table><tr><th>보존</th><td>노란색·초록색 제품 원본 엔티티 4개 좌표·원호·폭·상태 일치. 제품에 턱·홈·가이드 추가 없음.</td></tr><tr><th>왼쪽 접속 중심</th><td>아래 좌표는 원본 중심 기준 (원점 원본 X=282.5006121, Y=107.1826197 mm). 초록 (-74.774808, 101.500000), 노랑 (-70.800000, 103.005739). 오른쪽 거울 대칭.</td></tr><tr><th>목 / 몸통</th><td>초록 0.350 mm, 노랑 0.250 mm. 몸통 약 0.650 mm. 접속 중심 거리 4.250453 mm. 단순 원호가 아닌 매끄러운 가변 폭 곡선이며 DXF는 분할선 근사.</td></tr><tr><th>도면 해석</th><td>원래 목의 끝면은 기존 제품 폐곡선을 명시하는 선이며 제품 부피 추가가 아님. 새 연결부와 겹치는 제품선은 재료 경계 표시로, 절개 틈이 아님. 금형 와이어 가공용 윤곽도가 아님.</td></tr><tr><th>적용 한계</th><td>두 목 완전 파단·버·고온 소성·6 m 길이 방향 분리 미검증. 완전 분리 뒤의 조건부 낙하 결과는 별도 보고서 참조. 0.25 mm 목의 충전성, 금형 강도와 곡선 피팅은 금형사 검토 필요.</td></tr></table></html>'''
    HTML(string=html,base_url=str(DEST)).write_pdf(DEST/'bridge_relocated_revC_CONCEPT.pdf')
    print(json.dumps(meta,indent=2))

if __name__=='__main__':main()
