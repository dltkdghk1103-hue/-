"""Rev B: preserve every yellow/green DXF entity; change white bridge lines only."""
from pathlib import Path
import json, zipfile, shutil, hashlib
import numpy as np
import ezdxf
from ezdxf.path import make_path
from shapely.geometry import Polygon, LineString
from shapely import set_precision, union_all
from shapely.affinity import translate
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import markdown
from weasyprint import HTML,CSS
import rigid_bridge as rb
from geometry_helpers import G,Y,L,R,C,OUT,XC,Y0,NECKS

DEST=OUT/'revision_B';DEST.mkdir(exist_ok=True)
doc=ezdxf.readfile(OUT/'ddfdfd.dxf');original=ezdxf.readfile(OUT/'ddfdfd.dxf')
protected=['F369','F36A','F3A2','F3A3']
white_replacements=[]
for handle,bulge in [('F36C',.3),('F36E',-.3)]:
    line=doc.entitydb[handle];a=line.dxf.start;b=line.dxf.end
    attr={k:line.dxf.get(k) for k in ['layer','color','linetype','lineweight'] if line.dxf.hasattr(k)}
    new=doc.modelspace().add_lwpolyline([(a.x,a.y,bulge),(b.x,b.y,0)],format='xyb',dxfattribs=attr)
    white_replacements.append(new.dxf.handle);doc.modelspace().delete_entity(line)
def curve(entity):return np.array([[v.x-XC,v.y-Y0] for v in make_path(entity).flattening(.0001)])
ln=set_precision(Polygon(np.vstack([curve(doc.entitydb[white_replacements[0]]),C['F36D'][::-1]])),1e-7)
rn=set_precision(Polygon(np.vstack([curve(doc.entitydb[white_replacements[1]]),C['F36F'][::-1]])),1e-7)
assert ln.is_valid and rn.is_valid
assert ln.difference(L).area<1e-8 and rn.difference(R).area<1e-8
total=union_all([G,Y,ln,rn]);assert total.is_valid and total.geom_type=='Polygon' and len(total.interiors)==1
assert G.intersection(ln).area<1e-8 and Y.intersection(ln).area<1e-8

doc.layers.new('REV_B_NOTES',dxfattribs={'color':1})
notes=['REV B / BRIDGE ONLY / NOT FOR PRODUCTION',
 'Yellow + green product entities are unchanged from the original DXF.',
 'No added steps, guides, grooves or protrusions on either product.',
 'Original coordinates and mm units retained; cross-section 1:1.',
 'Both necks remain 0.250 mm; connection endpoints unchanged.',
 'Only the two white upper LINE entities changed to circular arcs.',
 'Arc radius ~1.533 mm, sag ~0.253 mm; bridge lies inside original envelope.',
 'Complete separation and inward release NOT verified.',
 'After complete bridge removal: product nesting geometry equals original.',
 'Rev A (product guides / 0.30 mm yellow neck) is WITHDRAWN.']
for i,n in enumerate(notes):doc.modelspace().add_text(n,dxfattribs={'layer':'REV_B_NOTES','height':2.5,'insert':(170,290-i*5)})
file=DEST/'modified_bridge_only_revB_CONCEPT.dxf';doc.saveas(file)
read=ezdxf.readfile(file);assert not read.audit().has_errors
checks={}
for h in protected:
    a=original.entitydb[h];b=read.entitydb[h]
    same=np.array_equal(np.array(a.get_points()),np.array(b.get_points())) and a.closed==b.closed and a.dxf.color==b.dxf.color and a.dxf.layer==b.dxf.layer
    assert same
    checks[h]={'product':'green' if a.dxf.color==3 else 'yellow','all_vertices_widths_bulges_identical':bool(same),'vertex_count':len(a)}

# Existing elastic screening model, same product motion and end constraints.
rb.L=ln
screen=[]
for h in [.015,.0075]:
    res,fields=rb.solve(h);screen.append(res)
    assert res['net_force_residual']<1e-7 and res['free_force_residual']<1e-7
orig_results=json.loads((OUT/'rigid_results.json').read_text())
oldcoef=orig_results['mesh_convergence'][-1]['neck']['left_green']['nominal_equivalent_per_q']
newcoef=screen[-1]['neck']['left_green']['nominal_equivalent_per_q']
ratio=oldcoef/newcoef
# Mid-chord thickness, measured perpendicular to the original straight upper edge.
a,b=C['F36C'];u=(b-a)/np.linalg.norm(b-a);normal=np.array([u[1],-u[0]]);mid=(a+b)/2
cut=LineString([mid-2*normal,mid+2*normal]);middle_t=ln.intersection(cut).length
sampling=[]
for down in [0,1,5,10,20,25,30,40]:
    area=G.intersection(translate(Y,yoff=-down)).area
    sampling.append({'down_mm':down,'original_and_revB_overlap_area_mm2_after_complete_bridge_removal':area})
checks_out={'revision':'B - bridge-only concept','product_entities':checks,'white_upper_edges_replaced':2,
 'bridge_subset_of_original_area_difference_mm2':float(ln.difference(L).area),
 'end_neck_mm':[.25,.25],'arc_radius_mm':float(np.linalg.norm(b-a)*(1+.3**2)/(4*.3)),
 'arc_sag_mm':float(np.linalg.norm(b-a)*.3/2),'bridge_area_mm2':ln.area,'middle_normal_thickness_mm':middle_t,
 'elastic_screening':screen,'nominal_green_neck_yield_load_ratio_revB_to_original':ratio,
 'nesting_samples':sampling,'fracture_propagation_verified':False,'inward_release_verified':False,'extrusion_die_verified':False}
(DEST/'revB_geometry_and_screening_checks.json').write_text(json.dumps(checks_out,indent=2))
print(json.dumps({k:v for k,v in checks_out.items() if k!='elastic_screening'},indent=2),flush=True)

font=FontProperties(fname='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams['font.family']=font.get_name();plt.rcParams['axes.unicode_minus']=False
fig,axs=plt.subplots(1,3,figsize=(16,6.5),gridspec_kw={'width_ratios':[1,1,1.1]})
for ax,parts in zip(axs,[[G,Y,L,R],[G,Y,ln,rn],[G,translate(Y,yoff=-25)]]):
    for p,col in zip(parts,['#299849','#d7ad00','#888888','#888888']):
        xy=np.array(p.exterior.coords);ax.fill(*xy.T,color=col,alpha=.8)
    ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_xlabel('x [mm]');ax.set_ylabel('y [mm]')
for ax in axs[:2]:ax.set_xlim(-76,-72.5);ax.set_ylim(102.7,105)
axs[0].set_title('원본 연결부',fontproperties=font)
axs[1].set_title('Rev B: 흰색 상부 선만 원호로 변경',fontproperties=font)
axs[1].plot(*C['F36C'].T,color='red',ls='--',lw=1,label='원본 상부 직선')
axs[1].annotate('R1.533 / 처짐 0.253 mm\n양 끝 목 0.25 mm 유지',xy=(-74.2,103.6),xytext=(-75.8,102.85),fontproperties=font,fontsize=10,arrowprops={'arrowstyle':'->'})
axs[2].set_title('연결부 완전 제거 후 25 mm 하강 예시\n제품 형상·포개짐 조건은 원본과 동일',fontproperties=font)
fig.suptitle('Rev B — 제품 윤곽 변경 없음 / 연결부만 변경한 검토안',fontproperties=font,fontsize=17)
fig.text(.5,.025,'빨간 점선: 원본 연결부 상부선. 새 연결부는 원래 흰색 영역 안에 있습니다. 잔여 연결부·파단·내부 배출은 미검증입니다.',fontproperties=font,ha='center',fontsize=10)
fig.tight_layout(rect=(0,.06,1,.92));fig.savefig(DEST/'revB_comparison.png',dpi=170);plt.close(fig)

newsection=f'''## 7. 정정: 제품 형상 변경 금지와 연결부만 변경하는 Rev B

이전 Rev A에서 추가한 초록색 안내 턱과 노란색 쪽 목 0.30 mm 변경은 철회한다. 안내 턱은 제품을 포개는 경로를 방해할 수 있고, 노란색 목 확대 역시 제품의 국부 윤곽을 변경했다. 이는 제품 형상을 보존해야 한다는 조건에 맞지 않았다.

**Rev B에서는 노란색·초록색 제품의 모든 DXF 꼭짓점, 곡선 bulge, 폭, 열린/닫힌 상태, 색상과 레이어를 원본 그대로 보존했다. 좌표 원점과 mm 단위도 원본과 같다.** 추가 턱, 홈, 가이드 또는 돌출부를 제품에 만들지 않았다.

흰색 연결부의 상부 직선 두 개만 원호로 변경했다. 왼쪽은 bulge +0.3, 오른쪽은 -0.3의 거울 대칭이다. 하부 곡선과 모든 접속 끝점은 유지했다. 원호 반경 약 1.533 mm, 원래 직선에서 안쪽으로 들어가는 최대 깊이 약 0.253 mm이며, 양 끝 연결 목은 모두 0.250 mm이다. 중앙에서 원래 직선의 수직 방향으로 측정한 연결부 두께는 약 {middle_t:.3f} mm이다. 새 연결부 영역 전체가 원래 흰색 영역 안에 있음을 확인했다.

이 형태는 중앙 몸통을 줄여 연결부가 더 쉽게 굽혀지는 후보이다. 동일한 탄성 단면 모델로 재비교했을 때, 초록색 목의 공칭 항복 지표에 도달하는 하중은 원본의 약 {ratio*100:.0f}%였다. 이는 **같은 경계조건에서 목 단면 지표를 비교한 것**이며, 실제 최초 항복·완전 분리 하중 또는 파단 위치를 확정한 결과가 아니다. 몸통의 국부 손상과 대변형까지 평가한 최적 설계가 아니다. 두 번째 목 분리, 안쪽 회전·배출, 금형 유동은 아직 확인되지 않았다.

제품을 포개는 문제는 연결부가 완전히 제거된 경우와 잔여 연결부가 붙어 있는 경우를 구분해야 한다. 완전히 제거한 경우에는 두 제품의 형상이 원본과 정확히 같으므로 어떤 상대 위치에서도 원본 대비 추가 간섭은 생기지 않는다. 하강 25 mm 예시에서 제품 간 겹침 면적은 0이었다. 이 값은 최종 조립 스트로크를 뜻하지 않는다. 연결부가 일부 남아 있거나 파단 후 조각이 움직이는 중에는 걸림이 생길 수 있으며, 그 동작은 검증하지 않았다.

흰색 연결부만 바꾸는 조건에서 한 번의 하강으로 두 목이 모두 끊어지고 조각이 확실히 내부로 들어간다고 현재 계산만으로 보증할 수 없다. 추가 제품 턱을 넣어 해결된 것처럼 표현하지 않는다. 원본과 Rev B 시편을 비교하여 파단 순서와 잔여 연결부 간섭을 먼저 확인해야 한다. 금형 제작사는 현재 0.25 mm 연결부와 새 원호의 충전성·용착선·다이 강도를 검토해야 한다.

![원본과 Rev B 비교](revB_comparison.png)

'''
md=(OUT/'report_ko.md').read_text()
start=md.index('## 7.');end=md.index('## 8.')
md=md[:start]+newsection+md[end:]
md=md.replace('# A6063 연결 압출품: 연결부 분리 검토','# A6063 연결 압출품: 원본 분석 및 연결부만 변경한 Rev B')
md=md.replace('**산출물:** 원본 DXF, 계산 코드, 결과 JSON, 그림. 원본 제품 도면은 수정하지 않았다. 이전의 제품 판 휨 검토 모델은 최종 결과에서 제외했다.', '**산출물:** 원본 DXF, 연결부만 변경한 Rev B DXF, 계산 코드와 결과 JSON, 비교 그림. 이전 Rev A는 철회했다. 노란색·초록색 제품 형상은 변경하지 않았다.')
md=md.replace('## 3. 세 단계의 비교','## 3. 원본 형상의 세 단계 비교')
notice='**정정 안내:** 이전 Rev A의 안내 턱과 제품 윤곽 변경을 철회합니다. 이 보고서 1–6절의 수치는 원본 연결부의 결과이며, 연결부만 변경한 Rev B의 제한적인 비교는 7절에 별도로 적었습니다.\n\n'
md=md.replace('\n\n**판정:**','\n\n'+notice+'**판정:**',1)
(DEST/'corrected_report_revB_KO.md').write_text(md)
body=markdown.markdown(md,extensions=['tables'])
styles='''@page{size:A4;margin:17mm 14mm;@bottom-center{content:counter(page);font-size:9pt}}body{font-family:"Noto Sans CJK KR",sans-serif;font-size:9pt;line-height:1.55}h1{font-size:18pt}h2{font-size:13pt;break-after:avoid}h3{font-size:11pt;break-after:avoid}table{border-collapse:collapse;width:100%;font-size:8pt}td,th{border:1px solid #aaa;padding:4px}img{max-width:100%}strong{color:#933}'''
for name in ['geometry.png','rigid_bridge_stress.png','clearance.png']:shutil.copy2(OUT/name,DEST/name)
page='<!doctype html><html lang="ko"><meta charset="utf-8"><title>원본 분석 및 연결부 수정 Rev B</title><style>'+styles+'</style><body>'+body+'</body></html>'
(DEST/'corrected_report_revB_KO.html').write_text(page)
HTML(string=page,base_url=str(DEST)).write_pdf(DEST/'corrected_report_revB_KO.pdf')
drawing='''<!doctype html><html lang="ko"><meta charset="utf-8"><style>@page{size:A3 landscape;margin:12mm}body{font-family:"Noto Sans CJK KR",sans-serif;font-size:11pt;line-height:1.6}h1{font-size:18pt;color:#933}img{width:100%}table{border-collapse:collapse;width:100%}td,th{border:1px solid #aaa;padding:6px}</style><body><h1>Rev B — 흰색 연결부만 변경한 검토용 도면</h1><p>A6063 · 최종 T5 가정 · 길이 6,000 mm · DXF 단위 mm, 단면 1:1, 원본 좌표 유지 · PDF 그림은 도식 축척</p><img src="revB_comparison.png"><table><tr><th>변경 금지 영역</th><td>노란색·초록색 제품의 모든 좌표와 원호를 원본 그대로 보존. 원본 제품 엔티티 4개의 전체 꼭짓점·폭·bulge를 저장 후 재검증.</td></tr><tr><th>변경 내용</th><td>흰색 연결부의 상부 직선 2개만 원호로 변경. R 약 1.533 mm / 원호 깊이 약 0.253 mm. 양 끝 목 0.25 mm와 접속 끝점 유지. 하부 곡선 유지.</td></tr><tr><th>포개짐</th><td>연결부 완전 제거 시 원본 대비 추가 제품 간섭 없음. 예시 하강량은 25 mm이며 최종 조립 스트로크를 의미하지 않음. 잔여 연결부의 걸림은 미검증.</td></tr><tr><th>철회 내용</th><td>Rev A의 내부 안내 턱과 노란색 목 0.30 mm 변경을 철회함. 제품에 가이드·홈·돌출부 추가 없음.</td></tr></table><p><strong>제작 확정 도면이 아닙니다. 완전 파단·내부 배출·압출 유동·금형 강도는 아직 검증하지 않았습니다.</strong></p></body></html>'''
HTML(string=drawing,base_url=str(DEST)).write_pdf(DEST/'modified_bridge_only_revB_CONCEPT.pdf')
shutil.copy2(OUT/'ddfdfd.dxf',DEST/'original_profile_UNCHANGED.dxf')
(DEST/'READ_ME_KO.txt').write_text('Rev B: 제품 윤곽은 원본과 동일합니다. 흰색 상부 직선 2개만 원호로 변경했습니다.\n이전 Rev A는 철회했습니다.\n기존 원본 계산은 보고서 1–6절, Rev B의 제한적 탄성 비교는 7절에 있습니다.\n잔여 연결부 간섭, 완전 분리·내부 배출, 금형 제작 가능성은 검증 전입니다.\n')
with zipfile.ZipFile(DEST/'revB_calculation_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in ['build_revB.py','rigid_bridge.py','geometry_helpers.py','requirements.txt','ddfdfd.dxf','rigid_results.json']:z.write(OUT/f,f)
    z.write(DEST/'revB_geometry_and_screening_checks.json','revB_geometry_and_screening_checks.json')
bundle=DEST/'report_and_modified_drawings.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(DEST.iterdir()):
        if f.is_file() and f!=bundle:z.write(f,f.name)
with zipfile.ZipFile(bundle) as z:assert z.testzip() is None
print('Rev B files ready',flush=True)
