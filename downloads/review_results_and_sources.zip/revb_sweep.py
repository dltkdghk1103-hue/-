from revb_contact import *
from concurrent.futures import ProcessPoolExecutor,as_completed
from collections import Counter

if __name__=='__main__':
    cases=[]
    for mu in [.1,.3,.6]:
        for vx in [-100,0,100]:
            for vy in [-100,0,100]:
                for omega in [-20,0,20]:
                    cases.append({'id':f'mu{mu}_vx{vx}_vy{vy}_w{omega}','group':'release_sensitivity','mu':mu,'vx':vx,'vy':vy,'omega':omega,'duration':.4})
    for mu in [0,.05,.15,.2,.25,.4,.5]:
        cases.append({'id':f'friction_{mu}','group':'friction','mu':mu,'duration':.5})
    for mu in [.1,.3,.6]:
        cases.append({'id':f'fine_{mu}','group':'refinement','mu':mu,'duration':.6,'dt':.000005,'iterations':120,'slop':.0001,'surface_tol':.0001})
    for rest in [0,.3]:
        for mu in [.1,.3,.6]:cases.append({'id':f'restitution_{rest}_{mu}','group':'restitution','mu':mu,'restitution':rest,'duration':.5})
    for mu in [.1,.3,.6]:
        cases.append({'id':f'force200fine_{mu}','group':'force_refinement','mu':mu,'yellow_mode':'force','hand_force_N':200,'duration':.4,'dt':.000005,'iterations':180,'slop':.0001,'surface_tol':.0001})
    results=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        jobs={pool.submit(run_case,c):c for c in cases}
        for f in as_completed(jobs):
            r=f.result();results.append(r)
            print(json.dumps({k:v for k,v in r.items() if k!='history'}),flush=True)
    results.sort(key=lambda r:r['case']['id'])
    out={'sanity':sanity(),'cases':results,'status_counts':dict(Counter(x['status'] for x in results))}
    (DEST/'sweep.json').write_text(json.dumps(out))
    print('SUMMARY',json.dumps(out['status_counts']),flush=True)
